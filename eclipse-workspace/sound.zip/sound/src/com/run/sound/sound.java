package com.run.sound;

import java.io.IOException;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

@WebServlet("/sound")
public class sound extends HttpServlet {
	String user;
	String password;
	boolean status;
	@Override
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
	user=request.getParameter("username");
	password=request.getParameter("password");
	status=LoginDao.validate(user, password);

	if(status){
		RequestDispatcher rd=request.getRequestDispatcher("raise.html");
		rd.forward(request,response);
	}
	else{
		RequestDispatcher rd=request.getRequestDispatcher("errr.html");
		rd.include(request,response);
	}
	
/*	
	if(user.equals("mahesh") && password.equals("sound")) {

		RequestDispatcher rd=request.getRequestDispatcher("output1.jsp"); 
		rd.forward(request, response);
	}
	else {

		RequestDispatcher rd=request.getRequestDispatcher("output2.jsp"); 
		rd.forward(request, response);	
	}
*/
	}
@Override
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		doGet(request, response);
	}
}
