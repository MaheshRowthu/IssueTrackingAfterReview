package com.track.service;

import com.track.model.Issue;
import com.track.model.TechEngineer;

public class TechEngineerServiceImpl implements TechEngineerService {

	@Override
	public TechEngineer ViewAssignedTickets(Issue i) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public TechEngineer UpdateTicketStatus(Issue i) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public TechEngineer ViewOfResolvedTickets(Issue i) {
		// TODO Auto-generated method stub
		return null;
	}

}
