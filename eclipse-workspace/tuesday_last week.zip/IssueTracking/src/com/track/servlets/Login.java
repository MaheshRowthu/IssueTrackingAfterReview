package com.track.servlets;

import java.io.IOException;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.track.dao.EmployeeDao;
import com.track.dao.EmployeeDaoImpl;
import com.track.model.Employee;

/**
 * Servlet implementation class Login
 */
@WebServlet({ "/Login", "/logi" })
public class Login extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public Login() {
        super();
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		response.getWriter().append("Served at: ").append(request.getContextPath());
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	@Override
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		String emptype=request.getParameter("type");
		String name=request.getParameter("user");
		String pass=request.getParameter("pass");
		Employee emp=new Employee(name,pass,emptype);
		EmployeeDao empDao=new EmployeeDaoImpl();
		
		if(emptype.equals("normal") && empDao.validateLogin(emp)) {
			Employee employee = new Employee();
			employee.setMail(emp.getMail());
			        
			request.setAttribute("Employee", employee);
			request.getRequestDispatcher("homepageOfEmployee.jsp").forward(request, response);
//			RequestDispatcher rd = request.getRequestDispatcher("homepageOfEmployee.jsp");
//			rd.forward(request, response);
			//response.sendRedirect("homepageOfEmployee.jsp");
	
			System.out.println("Succeed");
			return;
		}
		if( emptype.equals("admin") && empDao.validateLogin(emp) ) {
			//request.getRequestDispatcher("homepageOfAdmin.jsp");//.forward(request, response);

			RequestDispatcher rd1 = request.getRequestDispatcher("homepageOfAdmin.jsp");
			rd1.include(request, response);
		//	response.sendRedirect("homepageOfAdmin.jsp");
	
			System.out.println("Succeed");
			return;
		}
		if(emptype.equals("tech") && empDao.validateLogin(emp)){
//			RequestDispatcher rd2 = request.getRequestDispatcher("homepageOfTech.jsp");
//			rd2.forward(request, response);
			response.sendRedirect("homepageOfTech.jsp");
			System.out.println("Succeed");
			return;
		}
		else {
			RequestDispatcher rd3 = request.getRequestDispatcher("errr.jsp");
			rd3.forward(request, response);
			System.out.println("Fail");
		}

	}

}
