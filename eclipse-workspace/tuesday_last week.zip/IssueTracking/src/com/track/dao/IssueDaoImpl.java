package com.track.dao;

import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import org.apache.log4j.Logger;

import com.track.connect.DbConnection;
import com.track.model.Issue;

public class IssueDaoImpl implements IssueDao {
	private static final Logger log = Logger.getRootLogger();

	DbConnection sc = new DbConnection();
	PreparedStatement ps = null;

	ResultSet rs = null;

	@Override
	public Issue checkStatus(Issue i) {

		return null;
	}

	public List<Issue> viewRaisedTickets() {
		String sql = "select empid,issueid,issuetype,issuedesc,priority,status,postedon,solvedon,techid from Issue where status=?";
		List<Issue> raisedIssueList = new ArrayList<>();
		try {
			ps = DbConnection.getConnection().prepareStatement(sql);

			String status = "At Admin";
			ps.setString(1, status);
			rs = ps.executeQuery();
			while (rs.next()) {
				log.debug(rs);
				raisedIssueList.add(getRaisedTicketResultSet(rs));
				
			}
			rs.close();
			ps.close();

		} catch (SQLException e) {
			log.error(e);
		}

		return raisedIssueList;
	}

	private Issue getRaisedTicketResultSet(ResultSet rs) {
		try {
			int empId = rs.getInt(1);
			int issueId = rs.getInt(2);
			String issueType = rs.getString(3);
			String issueDesc = rs.getString(4);
			int priority = rs.getInt(5);
			String status = rs.getString(6);
			String postedOn = rs.getString(7);
			String solvedOn = rs.getString(8);
			int solvedBy = rs.getInt(9);

			Issue issueListRaisedObj = new Issue(empId, issueId, issueType, issueDesc, priority, status, postedOn,
					solvedOn, solvedBy);
			log.debug(issueListRaisedObj);
			log.trace(issueListRaisedObj);
			return issueListRaisedObj;
		} catch (Exception e) {
			log.error(e);
		}
		return null;
	}

	
}
