package com.track.dao;

import java.util.List;

import com.track.model.Issue;

public interface IssueDao {
	Issue checkStatus(Issue i);
	List<Issue> viewRaisedTickets();

}
