package com.track.dao;

import static org.junit.Assert.fail;

import org.junit.After;
import org.junit.AfterClass;
import org.junit.Assert;
import org.junit.Before;
import org.junit.BeforeClass;
import org.junit.Test;

import com.track.model.Employee;

public class EmployeeDaoTest {


	private EmployeeDao empdao;
	
	@Test
	public void testRaiseTicket() {
//	Employee emp=empdao.raiseTicket();
//	 Assert.assertEquals("John Smith", empdao.getEmpRaiseTicket());
     return;
	}

	@Test
	public void testCheckStatus() {
	}

	@Test
	public void testViewRaisedTickets() {
		fail("Not yet implemented");
	}

	@Test
	public void testViewTicketsAssigned() {
		fail("Not yet implemented");
	}

	@Test
	public void testViewResolvedTickets() {
		fail("Not yet implemented");
	}

}
