package com.track.service;

import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

import com.track.connect.DbConnection;
import com.track.model.Employee;
import com.track.model.Issue;

public class EmployeeServiceImpl implements EmployeeService {
	// EmployeeService empservice = new EmployeeServiceImpl();
	DbConnection sc = new DbConnection();
	 PreparedStatement stmt=null;
	 ResultSet rs=null;


	@Override
	public boolean validateLogin(Employee emp) {
		
		boolean status=false;
		
		try {
			
//			Class.forName("oracle.jdbc.OracleDriver");
//			Connection con = DriverManager.getConnection("jdbc:oracle:thin:@localhost:1521:xe", "system", "manager");
//			PreparedStatement stmt = null;//
			if (emp.getEmptype().equals("normal")) {
				stmt = DbConnection.conn.prepareStatement("select * from employee where mail=? and password=? and type=?");
				stmt.setString(1, emp.getMail());
				stmt.setString(2, emp.getPassword());
				stmt.setString(3, emp.getEmptype());
				System.out.println("Succed emp query");
			}
			if (emp.getEmptype().equals("admin")) {
				stmt = DbConnection.getConnection().prepareStatement("select * from employee where mail=? and password=? and type=?");
				stmt.setString(1, emp.getMail());
				stmt.setString(2, emp.getPassword());
				stmt.setString(3, emp.getEmptype());

				System.out.println("Succed admin query");
			}
			if (emp.getEmptype().equals("tech")) {
				stmt = sc.conn.prepareStatement("select * from techteam where mail=? and password=?");
				stmt.setString(1, emp.getMail());
				stmt.setString(2, emp.getPassword());

				System.out.println("Succed tech query");
			}
			
				ResultSet rs = stmt.executeQuery();

				if(rs.next()) {
					System.out.println();
					//System.out.println(rs.getString(1) + ":" + rs.getString(2) + " " + rs.getString(3));
					status=true;
					rs.close();
					stmt.close();
					DbConnection.conn.close();
					
				}
				else
				{
					status=false;
				}
				
		} catch (SQLException e) {
			e.printStackTrace();
		} catch (NullPointerException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return status;
	}

	@Override
	public Employee raiseTicket(Issue i) {
		return null;// empservice.raiseTicket(i);
	}

	@Override
	public Employee checkStatus(Issue i) {
		return null;// empservice.checkStatus(i);
	}

}
