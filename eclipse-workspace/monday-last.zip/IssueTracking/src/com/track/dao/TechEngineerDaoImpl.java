package com.track.dao;

import com.track.model.TechEngineer;

public class TechEngineerDaoImpl implements TechEngineerDao {

	@Override
	public TechEngineer viewAssignedTickets() {

		return null;
	}

	@Override
	public TechEngineer updateStatuisOfTickets() {
		return null;
	}

	@Override
	public TechEngineer viewOfResolovedTickets() {
		return null;
	}

}
