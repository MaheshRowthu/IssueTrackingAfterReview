package com.track.dao;

import java.sql.Date;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.ArrayList;
import java.util.List;

import org.apache.log4j.Logger;

import com.track.connect.DbConnection;
import com.track.model.Employee;
import com.track.model.Issue;

public class EmployeeDaoImpl implements EmployeeDao {
	private static final Logger log = Logger.getRootLogger();

	DbConnection sc = new DbConnection();
	PreparedStatement st = null;
	ResultSet rs = null;

	/*
	 * public boolean validate(String desg, String name, String pass) {
	 * System.out.println(desg+" "+name+" "+pass); try { //
	 * Class.forName("oracle.jdbc.OracleDriver"); // Connection con =
	 * DriverManager.getConnection("jdbc:oracle:thin:@localhost:1521:xe", "system",
	 * "manager"); // PreparedStatement stmt = null;// DbConnection sc = new
	 * DbConnection();
	 * 
	 * if (desg.equals("associate") ) { st = DbConnection.conn.
	 * prepareStatement("select * from employee where mail=? and password=? and desg=?"
	 * ); st.setString(1, name); st.setString(2, pass); st.setString(3, desg);
	 * System.out.println("Succed emp query"); } if (desg.equals("admin") ) { st =
	 * sc.conn.
	 * prepareStatement("select * from employee where mail=? and password=? and desg=?"
	 * ); st.setString(1, name); st.setString(2, pass); st.setString(3, desg);
	 * 
	 * System.out.println("Succed admin query"); } if(desg.equals("tech") ){ st =
	 * sc.conn.prepareStatement("select * from techteam where mail=? and password=?"
	 * ); st.setString(1, name); st.setString(2, pass);
	 * 
	 * System.out.println("Succed tech query"); } ResultSet rs = st.executeQuery();
	 * while (rs.next()) { System.out.println(); System.out.println(rs.getString(1)
	 * + ":" + rs.getString(2) + " " + rs.getString(3)); // rs.getBigDecimal(1);
	 * return true;
	 * 
	 * } rs.close(); st.close();
	 * 
	 * } catch (SQLException e) { e.printStackTrace(); } return false;
	 * 
	 * }
	 */
	public Employee raiseTicket(Issue issue) {
		String sql = "insert into Issue(issueid,issuetype,issuedesc,priority,status,postedon,empid) values(Issue_seq.nextval,?,?,?,?,?,?)";
		try {
			st = DbConnection.conn.prepareStatement(sql);
			st.setString(1, issue.getIssType());
			st.setString(2, issue.getIssDesc());
			st.setInt(3, issue.getPriority());
			String status = "At Admin";
			st.setString(4, status);
			long millis = System.currentTimeMillis();
			Date dateObj = new Date(millis);
			System.out.println(dateObj);
			String date = "" + dateObj;

			st.setString(5, date);
			st.setInt(6, issue.getEmpId());
			ResultSet rs = st.executeQuery();
			rs.close();
			st.close();
			DbConnection.conn.commit();
			DbConnection.conn.close();

//			while (rs.next()) {
//				System.out.println();
//				System.out.println(rs.getString(1) + ":" + rs.getString(2) + " " + rs.getString(3));
//				// rs.getBigDecimal(1);
//				
//				
//			}

		} catch (Exception e) {
			e.printStackTrace();
		}
		return null;
	}

	public Issue checkStatus(Issue issueObj) {
		int empId = 0;
		int issueId = 0;
		String issueType = "";
		String issueDesc = "";
		int priority = 0;
		String status = "";
		String postedOn = "";
		String solvedOn = "";
		String sql = "select empid,issueid,issuetype,issuedesc,priority,status,postedon,solvedon from Issue where empid=(select empid from employee where mail=?)";

		try {
			st = DbConnection.getConnection().prepareStatement(sql);
			String mail = issueObj.getMailId();
			log.debug(mail);
			st.setString(1, mail);

			rs = st.executeQuery();
			while (rs.next()) {
				empId = rs.getInt(1);
				issueId = rs.getInt(2);
				issueType = rs.getString(3);
				issueDesc = rs.getString(4);
				priority = rs.getInt(5);
				status = rs.getString(6);
				postedOn = rs.getString(7);
				solvedOn = rs.getString(8);
				log.debug("" + empId + "," + issueId + "," + issueType + "," + issueDesc + "," + priority + ","
						+ status + "," + postedOn + "," + solvedOn);
				Issue issueObj2 = new Issue(empId, issueId, issueType, issueDesc, priority, status, postedOn, solvedOn);
				return issueObj2;
				/*
				List<String> issuelist = new ArrayList<>();
				issuelist.add(1, "" + empId);
				issuelist.add(2, issueId + "");
				issuelist.add(3, issueType);
				issuelist.add(4, issueDesc);
				issuelist.add(5, priority + "");
				issuelist.add(6, status);
				issuelist.add(7, postedOn);
				issuelist.add(8, solvedOn);
				*/
			}

			System.out.println();
		} catch (Exception e) {
			e.printStackTrace();
		}
		return null;
	}

	public Employee viewRaisedTickets(Issue i) {
		String sql = "select * from Issue";

		try {
			st = DbConnection.getConnection().prepareStatement(sql);
			st.setInt(1, i.getIssId());
			st.setString(2, i.getIssType());
			st.setString(3, i.getIssDesc());
			st.setInt(4, i.getPriority());
			st.setString(5, i.getStatus());
			st.setString(6, i.getPostedOn());
			st.setInt(7, i.getEmpId());
			st.setInt(8, i.getTechId());
			st.setString(9, "");
		} catch (Exception e) {
			log.error(e);
		}
		return null;
	}

	@Override
	public Employee viewTicketsAssigned(Issue i) {
		String sql = "select * from Issue where status='assigned'";

		try {
			st = DbConnection.getConnection().prepareStatement(sql);
			st.setInt(1, i.getIssId());
			st.setString(2, i.getIssType());
			st.setString(3, i.getIssDesc());
			st.setInt(4, i.getPriority());
			st.setString(5, i.getStatus());
			st.setString(6, i.getPostedOn());
			st.setInt(7, i.getEmpId());
			st.setInt(8, i.getTechId());
			st.setString(9, "");
		} catch (Exception e) {
			e.printStackTrace();
		}
		return null;
	}

	@Override
	public Employee viewResolvedTickets(Issue i) {
		String sql = "select * from Issue where status='resolved'";

		try {
			st = DbConnection.getConnection().prepareStatement(sql);
			st.setInt(1, i.getIssId());
			st.setString(2, i.getIssType());
			st.setString(3, i.getIssDesc());
			st.setInt(4, i.getPriority());
			st.setString(5, i.getStatus());
			st.setString(6, i.getPostedOn());
			st.setInt(7, i.getEmpId());
			st.setInt(8, i.getTechId());
			st.setString(9, "");
		} catch (Exception e) {
			e.printStackTrace();
		}
		return null;
	}

}