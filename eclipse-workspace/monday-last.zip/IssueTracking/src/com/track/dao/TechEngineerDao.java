package com.track.dao;

import com.track.model.TechEngineer;

public interface TechEngineerDao {
	
	TechEngineer viewAssignedTickets();
	TechEngineer updateStatuisOfTickets();
	TechEngineer viewOfResolovedTickets();
	
	
}
