package com.track.dao;

import com.track.model.Employee;
import com.track.model.Issue;

public interface IssueDao {
	Issue checkStatus(Issue i);

}
