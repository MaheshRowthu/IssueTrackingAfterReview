package com.track.dao;

import com.track.model.Issue;

public class IssueDaoImpl implements IssueDao{

	@Override
	public Issue checkStatus(Issue i) {
		
		return null;
	}

}
