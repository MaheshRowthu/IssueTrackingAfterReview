package com.track.servlets;

import java.io.IOException;
import java.util.List;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.track.dao.EmployeeDao;
import com.track.dao.EmployeeDaoImpl;
import com.track.model.Issue;

/**
 * Servlet implementation class TicketStatusServlet
 */
@WebServlet({ "/TicketStatusServlet", "/ticketstatus" })
public class EmpTicketStatusServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public EmpTicketStatusServlet() {
        super();
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		response.getWriter().append("Served at: ").append(request.getContextPath());
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		String mail=request.getParameter("mailId");
		System.out.println("mail from jsp is"+mail);
		Issue issueObj=new Issue(mail);
		EmployeeDao empDao=new EmployeeDaoImpl();
		Issue issueObj2=empDao.checkStatus(issueObj);
		String getempid=issueObj2.getIssDesc();
		
		
		request.setAttribute("empid", issueObj2.getEmpId());
		request.setAttribute("issueid",issueObj2.getIssId());
		request.setAttribute("issuetype",issueObj2.getIssType());
		request.setAttribute("issuedesc",issueObj2.getIssDesc());
		request.setAttribute("priority",issueObj2.getPriority());
		request.setAttribute("status",issueObj2.getStatus());
		request.setAttribute("postedon", issueObj2.getPostedOn());
		request.setAttribute("solvedon",issueObj2.getSolvedOn());
		
		RequestDispatcher rd=request.getRequestDispatcher("EmpCheckStatus.jsp");
		rd.forward(request, response);
	}

}
