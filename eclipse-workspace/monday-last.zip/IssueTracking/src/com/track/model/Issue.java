package com.track.model;

public class Issue {
	private int IssId;
	private String IssType;
	private String IssDesc;
	private String PostedOn;
	private int Priority;
	private String Status;
	private int EmpId;
	private String mailId;

	private int TechId;
	private String SolvedOn;

	public Issue(int issId, String issType, String issDesc, String postedOn, int priority, String status, int empId,
			int techId, String solvedOn) {
		super();
		IssId = issId;
		IssType = issType;
		IssDesc = issDesc;
		Priority = priority;
		Status = status;
		EmpId = empId;
		TechId = techId;
	}

	public Issue(int empId, int issId, String issType, String issDesc, int priority, String status, String postedOn,
			String solvedOn) {
		super();
		IssId = issId;
		IssType = issType;
		IssDesc = issDesc;
		PostedOn = postedOn;
		Priority = priority;
		Status = status;
		EmpId = empId;
		SolvedOn = solvedOn;
	}

	public Issue(String issType, String issDesc, int priority, int empId) {
		super();
		IssType = issType;
		IssDesc = issDesc;
		Priority = priority;
		EmpId = empId;
	}

	public Issue() {
		super();
	}

	public Issue(String mail) {
		mailId = mail;
	}

	@Override
	public String toString() {
		return "Issue [IssId=" + IssId + ", IssType=" + IssType + ", IssDesc=" + IssDesc + ", Posted_on=" + PostedOn
				+ ", Priority=" + Priority + ", Status=" + Status + ", EmpId=" + EmpId + ", TechId=" + TechId
				+ ", Solved_on=" + SolvedOn + "]";
	}

	public int getIssId() {
		return IssId;
	}

	public void setIssId(int issId) {
		IssId = issId;
	}

	public String getIssType() {
		return IssType;
	}

	public void setIssType(String issType) {
		IssType = issType;
	}

	public String getIssDesc() {
		return IssDesc;
	}

	public void setIssDesc(String issDesc) {
		IssDesc = issDesc;
	}

	public String getPostedOn() {
		return PostedOn;
	}

	public void setPostedOn(String postedOn) {
		PostedOn = postedOn;
	}

	public int getPriority() {
		return Priority;
	}

	public void setPriority(int priority) {
		Priority = priority;
	}

	public String getStatus() {
		return Status;
	}

	public void setStatus(String status) {
		Status = status;
	}

	public int getEmpId() {
		return EmpId;
	}

	public void setEmpId(int empId) {
		EmpId = empId;
	}

	public String getMailId() {
		return mailId;
	}

	public void setMailId(String mailId) {
		this.mailId = mailId;
	}

	public int getTechId() {
		return TechId;
	}

	public void setTechId(int techId) {
		TechId = techId;
	}

	public String getSolvedOn() {
		return SolvedOn;
	}

	public void setSolvedOn(String solvedOn) {
		SolvedOn = solvedOn;
	}

}
