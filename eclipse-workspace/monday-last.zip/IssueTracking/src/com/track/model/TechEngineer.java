package com.track.model;

public class TechEngineer {
	private int techid;
	private String techname;
	private String mail;
	private String password;
	private int phno;
	private String address;
	private String role;

	public TechEngineer(int techid, String techname, String mail, String password, int phno, String address,
			String role) {
		super();
		this.techid = techid;
		this.techname = techname;
		this.mail = mail;
		this.password = password;
		this.phno = phno;
		this.address = address;
		this.role = role;
	}

	public String getTechname() {
		return techname;
	}

	public void setTechname(String techname) {
		this.techname = techname;
	}

	public String getPassword() {
		return password;
	}

	public void setPassword(String password) {
		this.password = password;
	}

	public int getPhno() {
		return phno;
	}

	public void setPhno(int phno) {
		this.phno = phno;
	}

	public String getAddress() {
		return address;
	}

	public void setAddress(String address) {
		this.address = address;
	}

	public String getRole() {
		return role;
	}

	public void setRole(String role) {
		this.role = role;
	}

	public int getTechid() {
		return techid;
	}

	public String getMail() {
		return mail;
	}

}
